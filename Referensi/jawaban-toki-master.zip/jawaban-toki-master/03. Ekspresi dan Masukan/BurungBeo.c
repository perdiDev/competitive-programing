#include <stdio.h>
int main () {
	char input [1001];
	gets(input);
	printf("%s\n", input);
}
