#include <stdio.h>
int main () {
	int n,m;
	scanf("%d %d",&n,&m);
	printf("masing-masing %d\n", n/m);
	printf("bersisa %d\n", n%m);
}
