#include <stdio.h>
int main () {
	int a;
	int jumlah =0;
	
	while(scanf("%d",&a) != EOF) {
		jumlah= jumlah+a;
		
	}
	printf("%d\n",jumlah);
}
