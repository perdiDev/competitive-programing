#include <stdio.h>
int main () {
	char a[101];
	
	while(scanf("%s",a)!= EOF) {
		printf("%s\n",a);
	}
}
